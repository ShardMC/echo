package tree;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.Opcodes;

import java.util.ArrayList;
import java.util.List;

/**
 * A node that represents an annotation.
 *
 * @author Eric Bruneton
 */
public class AnnotationNode extends AnnotationVisitor {

    /**
     * The class descriptor of the annotation class.
     */
    public String desc;

    /**
     * The name value pairs of this annotation. Each name value pair is stored as two consecutive
     * elements in the list. The name is a {@link String}, and the value may be a {@link Byte}, {@link
     * Boolean}, {@link Character}, {@link Short}, {@link Integer}, {@link Long}, {@link Float},
     * {@link Double}, {@link String} or {@link org.objectweb.asm.Type}, or a two elements String
     * array (for enumeration values), an {@link AnnotationNode}, or a {@link List} of values of one
     * of the preceding types. The list may be {@literal null} if there is no name value pair.
     */
    public List<Object> values;

    /**
     * Constructs a new {@link AnnotationNode}. <i>Subclasses must not use this constructor</i>.
     * Instead, they must use the {@link #AnnotationNode(int, String)} version.
     *
     * @param descriptor the class descriptor of the annotation class.
     * @throws IllegalStateException If a subclass calls this constructor.
     */
    public AnnotationNode(final String descriptor) {
        this(Opcodes.ASM9, descriptor);

        if (this.getClass() != AnnotationNode.class) {
            throw new IllegalStateException();
        }
    }

    /**
     * Constructs a new {@link AnnotationNode}.
     *
     * @param api        the ASM API version implemented by this visitor. Must be one of the {@code
     *                   ASM}<i>x</i> values in {@link Opcodes}.
     * @param descriptor the class descriptor of the annotation class.
     */
    public AnnotationNode(final int api, final String descriptor) {
        super(api);
        this.desc = descriptor;
    }

    /**
     * Constructs a new {@link AnnotationNode} to visit an array value.
     *
     * @param values where the visited values must be stored.
     */
    AnnotationNode(final List<Object> values) {
        super(Opcodes.ASM9);
        this.values = values;
    }

    // ------------------------------------------------------------------------
    // Implementation of the AnnotationVisitor abstract class
    // ------------------------------------------------------------------------

    /**
     * Makes the given visitor visit a given annotation value.
     *
     * @param annotationVisitor an annotation visitor. Maybe {@literal null}.
     * @param name              the value name.
     * @param value             the actual value.
     */
    public static void accept(final AnnotationVisitor annotationVisitor, final String name, final Object value) {
        if (annotationVisitor != null) {
            if (value instanceof String[] typeValue) {
                annotationVisitor.visitEnum(name, typeValue[0], typeValue[1]);
            } else if (value instanceof AnnotationNode annotationValue) {
                annotationValue.accept(annotationVisitor.visitAnnotation(name, annotationValue.desc));
            } else if (value instanceof List) {
                AnnotationVisitor arrayAnnotationVisitor = annotationVisitor.visitArray(name);
                if (arrayAnnotationVisitor != null) {
                    List<?> arrayValue = (List<?>) value;
                    for (Object o : arrayValue) {
                      AnnotationNode.accept(arrayAnnotationVisitor, null, o);
                    }

                    arrayAnnotationVisitor.visitEnd();
                }
            } else {
                annotationVisitor.visit(name, value);
            }
        }
    }

    private List<Object> getValues() {
        if (values == null) {
            values = new ArrayList<>(this.desc != null ? 2 : 1);
        }

        return values;
    }

    @Override
    public void visit(final String name, final Object value) {
        if (this.desc != null) {
            this.getValues().add(name);
        }

        /*if (value instanceof byte[] bytes) {
            values.add(Util.asArrayList(bytes));
        } else if (value instanceof boolean[] booleans) {
            values.add(Util.asArrayList(booleans));
        } else if (value instanceof short[] shorts) {
          values.add(Util.asArrayList(shorts));
        } else if (value instanceof char[] chars) {
            values.add(Util.asArrayList(chars));
        } else if (value instanceof int[] ints) {
            values.add(Util.asArrayList(ints));
        } else if (value instanceof long[] longs) {
            values.add(Util.asArrayList(longs));
        } else if (value instanceof float[] floats) {
            values.add(Util.asArrayList(floats));
        } else if (value instanceof double[] doubles) {
            values.add(Util.asArrayList(doubles));
        } else {*/
            values.add(value);
        //}
    }

    @Override
    public void visitEnum(final String name, final String descriptor, final String value) {
        if (this.desc != null) {
            this.getValues().add(name);
        }

        values.add(new String[] { descriptor, value });
    }

    @Override
    public AnnotationVisitor visitAnnotation(final String name, final String descriptor) {
        if (this.desc != null) {
            this.getValues().add(name);
        }

        AnnotationNode annotation = new AnnotationNode(descriptor);
        values.add(annotation);

        return annotation;
    }

    @Override
    public AnnotationVisitor visitArray(final String name) {
        if (this.desc != null) {
            this.getValues().add(name);
        }

        List<Object> array = new ArrayList<>();
        values.add(array);

        return new AnnotationNode(array);
    }

    // ------------------------------------------------------------------------
    // Accept methods
    // ------------------------------------------------------------------------

    /**
     * Makes the given visitor visit this annotation.
     *
     * @param annotationVisitor an annotation visitor. Maybe {@literal null}.
     */
    public void accept(final AnnotationVisitor annotationVisitor) {
        if (annotationVisitor != null) {
            if (values != null) {
                for (int i = 0, n = values.size(); i < n; i += 2) {
                  String name = (String) values.get(i);
                  Object value = values.get(i + 1);
                  accept(annotationVisitor, name, value);
                }
            }
            annotationVisitor.visitEnd();
        }
    }
}

