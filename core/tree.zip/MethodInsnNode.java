package tree;

import org.objectweb.asm.MethodVisitor;

import java.util.Map;

/**
 * A node that represents a method instruction. A method instruction is an instruction that invokes
 * a method.
 *
 * @author Eric Bruneton
 */
public class MethodInsnNode extends AbstractInsnNode {

  /**
   * The internal name of the method's owner class (see {@link
   * org.objectweb.asm.Type#getInternalName()}).
   *
   * <p>For methods of arrays, e.g., {@code clone()}, the array type descriptor.
   */
  public String owner;

  /**
   * The method's name.
   */
  public final String name;

  /**
   * The method's descriptor (see {@link org.objectweb.asm.Type}).
   */
  public final String desc;

  /**
   * Whether the method's owner class if an interface.
   */
  public final boolean itf;

  /**
   * Constructs a new {@link MethodInsnNode}.
   *
   * @param opcode      the opcode of the type instruction to be constructed. This opcode must be
   *                    INVOKEVIRTUAL, INVOKESPECIAL, INVOKESTATIC or INVOKEINTERFACE.
   * @param owner       the internal name of the method's owner class (see {@link
   *                    org.objectweb.asm.Type#getInternalName()}).
   * @param name        the method's name.
   * @param descriptor  the method's descriptor (see {@link org.objectweb.asm.Type}).
   * @param isInterface if the method's owner class is an interface.
   */
  public MethodInsnNode(
          final int opcode,
          final String owner,
          final String name,
          final String descriptor,
          final boolean isInterface) {
    super(opcode);
    this.owner = owner;
    this.name = name;
    this.desc = descriptor;
    this.itf = isInterface;
  }

  @Override
  public int getType() {
    return METHOD_INSN;
  }

  @Override
  public void accept(final MethodVisitor methodVisitor) {
    methodVisitor.visitMethodInsn(opcode, owner, name, desc, itf);
    acceptAnnotations(methodVisitor);
  }

  @Override
  public AbstractInsnNode clone(final Map<LabelNode, LabelNode> clonedLabels) {
    return new MethodInsnNode(opcode, owner, name, desc, itf).cloneAnnotations(this);
  }
}
