package tree;

import org.objectweb.asm.*;
import tree2.Util;

import java.util.ArrayList;
import java.util.List;

/**
 * A node that represents a method.
 *
 * @author Eric Bruneton
 */
public class MethodNode extends MethodVisitor {

    /**
     * The instructions of this method.
     */
    public final InsnList instructions;
    /**
     * The method's access flags (see {@link Opcodes}). This field also indicates if the method is
     * synthetic and/or deprecated.
     */
    public int access;
    /**
     * The method's name.
     */
    public String name;
    /**
     * The method's descriptor (see {@link Type}).
     */
    public String desc;
    /**
     * The method's signature. May be {@literal null}.
     */
    public String signature;
    /**
     * The internal names of the method's exception classes (see {@link Type#getInternalName()}).
     */
    public List<String> exceptions;
    /**
     * The method parameter info (access flags and name).
     */
    public List<ParameterNode> parameters;
    /**
     * The runtime visible annotations of this method. May be {@literal null}.
     */
    public List<AnnotationNode> visibleAnnotations;
    /**
     * The runtime invisible annotations of this method. May be {@literal null}.
     */
    public List<AnnotationNode> invisibleAnnotations;
    /**
     * The runtime visible type annotations of this method. May be {@literal null}.
     */
    public List<TypeAnnotationNode> visibleTypeAnnotations;
    /**
     * The runtime invisible type annotations of this method. May be {@literal null}.
     */
    public List<TypeAnnotationNode> invisibleTypeAnnotations;
    /**
     * The non-standard attributes of this method. May be {@literal null}.
     */
    public List<Attribute> attrs;
    /**
     * The default value of this annotation interface method. This field must be a {@link Byte},
     * {@link Boolean}, {@link Character}, {@link Short}, {@link Integer}, {@link Long}, {@link
     * Float}, {@link Double}, {@link String} or {@link Type}, or an two elements String array (for
     * enumeration values), a {@link AnnotationNode}, or a {@link List} of values of one of the
     * preceding types. May be {@literal null}.
     */
    public Object annotationDefault;
    /**
     * The number of method parameters than can have runtime visible annotations. This number must be
     * less or equal than the number of parameter types in the method descriptor (the default value 0
     * indicates that all the parameters described in the method descriptor can have annotations). It
     * can be strictly less when a method has synthetic parameters and when these parameters are
     * ignored when computing parameter indices for the purpose of parameter annotations (see
     * <a href="https://docs.oracle.com/javase/specs/jvms/se9/html/jvms-4.html#jvms-4.7.18">...</a>).
     */
    public int visibleAnnotableParameterCount;
    /**
     * The runtime visible parameter annotations of this method. These lists are lists of {@link
     * AnnotationNode} objects. May be {@literal null}.
     */
    public List<AnnotationNode>[] visibleParameterAnnotations;
    /**
     * The number of method parameters than can have runtime invisible annotations. This number must
     * be less or equal than the number of parameter types in the method descriptor (the default value
     * 0 indicates that all the parameters described in the method descriptor can have annotations).
     * It can be strictly less when a method has synthetic parameters and when these parameters are
     * ignored when computing parameter indices for the purpose of parameter annotations (see
     * <a href="https://docs.oracle.com/javase/specs/jvms/se9/html/jvms-4.html#jvms-4.7.18">...</a>).
     */
    public int invisibleAnnotableParameterCount;
    /**
     * The runtime invisible parameter annotations of this method. These lists are lists of {@link
     * AnnotationNode} objects. May be {@literal null}.
     */
    public List<AnnotationNode>[] invisibleParameterAnnotations;
    /**
     * The try catch blocks of this method.
     */
    public List<TryCatchBlockNode> tryCatchBlocks;

    /**
     * The maximum stack size of this method.
     */
    public int maxStack;

    /**
     * The maximum number of local variables of this method.
     */
    public int maxLocals;

    /**
     * The local variables of this method. May be {@literal null}
     */
    public List<LocalVariableNode> localVariables;

    /**
     * The visible local variable annotations of this method. May be {@literal null}
     */
    public List<LocalVariableAnnotationNode> visibleLocalVariableAnnotations;

    /**
     * The invisible local variable annotations of this method. May be {@literal null}
     */
    public List<LocalVariableAnnotationNode> invisibleLocalVariableAnnotations;

    /**
     * Whether the accept method has been called on this object.
     */
    private boolean visited;

    /**
     * Constructs a new {@link MethodNode}. <i>Subclasses must not use this constructor</i>. Instead,
     * they must use the {@link #MethodNode(int, int, String, String, String, String[])} version.
     *
     * @param access     the method's access flags (see {@link Opcodes}). This parameter also indicates if
     *                   the method is synthetic and/or deprecated.
     * @param name       the method's name.
     * @param descriptor the method's descriptor (see {@link Type}).
     * @param signature  the method's signature. May be {@literal null}.
     * @param exceptions the internal names of the method's exception classes (see {@link
     *                   Type#getInternalName()}). May be {@literal null}.
     * @throws IllegalStateException If a subclass calls this constructor.
     */
    public MethodNode(int access, String name, String descriptor, String signature, String[] exceptions) {
        this(Opcodes.ASM9, access, name, descriptor, signature, exceptions);
        if (this.getClass() != MethodNode.class) {
            throw new IllegalStateException();
        }
    }

    /**
     * Constructs a new {@link MethodNode}.
     *
     * @param api        the ASM API version implemented by this visitor. Must be one of the {@code
     *                   ASM}<i>x</i> values in {@link Opcodes}.
     * @param access     the method's access flags (see {@link Opcodes}). This parameter also indicates if
     *                   the method is synthetic and/or deprecated.
     * @param name       the method's name.
     * @param descriptor the method's descriptor (see {@link Type}).
     * @param signature  the method's signature. May be {@literal null}.
     * @param exceptions the internal names of the method's exception classes (see {@link
     *                   Type#getInternalName()}). May be {@literal null}.
     */
    public MethodNode(int api, int access, String name, String descriptor, String signature, String[] exceptions) {
        super(api);
        
        this.access = access;
        this.name = name;
        this.desc = descriptor;
        this.signature = signature;
        this.exceptions = Util.asArrayList(exceptions);
        if ((access & Opcodes.ACC_ABSTRACT) == 0) {
            this.localVariables = new ArrayList<>(5);
        }
        
        this.tryCatchBlocks = new ArrayList<>();
        this.instructions = new InsnList();
    }

    // -----------------------------------------------------------------------------------------------
    // Implementation of the MethodVisitor abstract class
    // -----------------------------------------------------------------------------------------------

    @Override
    public void visitParameter(String name, int access) {
        if (this.parameters == null) {
            this.parameters = new ArrayList<>(5);
        }
        
        this.parameters.add(new ParameterNode(name, access));
    }

    @Override
    public AnnotationVisitor visitAnnotationDefault() {
        return new AnnotationNode(
                new ArrayList<>(0) {
                    @Override 
                    public boolean add(Object o) {
                        annotationDefault = o;
                        return super.add(o);
                    }
                });
    }

    @Override
    public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
        AnnotationNode annotation = new AnnotationNode(descriptor);
        this.visibleAnnotations = visible ? Util.add(visibleAnnotations, annotation) : Util.add(invisibleAnnotations, annotation);
        
        return annotation;
    }

    @Override
    public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        TypeAnnotationNode typeAnnotation = new TypeAnnotationNode(typeRef, typePath, descriptor);
        if (visible) {
            this.visibleTypeAnnotations = Util.add(visibleTypeAnnotations, typeAnnotation);
        } else {
            this.invisibleTypeAnnotations = Util.add(invisibleTypeAnnotations, typeAnnotation);
        }
        
        return typeAnnotation;
    }

    @Override
    public void visitAnnotableParameterCount(int parameterCount, boolean visible) {
        if (visible) {
            this.visibleAnnotableParameterCount = parameterCount;
        } else {
            this.invisibleAnnotableParameterCount = parameterCount;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public AnnotationVisitor visitParameterAnnotation(int parameter, String descriptor, boolean visible) {
        AnnotationNode annotation = new AnnotationNode(descriptor);
        if (visible) {
            if (this.visibleParameterAnnotations == null) {
                int params = Type.getArgumentTypes(desc).length;
                visibleParameterAnnotations = (List<AnnotationNode>[]) new List<?>[params];
            }
            
            this.visibleParameterAnnotations[parameter] = 
                    Util.add(this.visibleParameterAnnotations[parameter], annotation);
        } else {
            if (this.invisibleParameterAnnotations == null) {
                int params = Type.getArgumentTypes(desc).length;
                this.invisibleParameterAnnotations = (List<AnnotationNode>[]) new List<?>[params];
            }
            
            this.invisibleParameterAnnotations[parameter] = 
                    Util.add(this.invisibleParameterAnnotations[parameter], annotation);
        }
        
        return annotation;
    }

    @Override
    public void visitAttribute(final Attribute attribute) {
        this.attrs = Util.add(attrs, attribute);
    }

    @Override
    public void visitFrame(int type, int numLocal, Object[] local, int numStack, Object[] stack) {
        this.instructions.add(
                new FrameNode(
                        type, 
                        numLocal, 
                        local == null ? null : getLabelNodes(local), 
                        numStack, 
                        stack == null ? null : getLabelNodes(stack)
                )
        );
    }

    @Override
    public void visitInsn(int opcode) {
        this.instructions.add(new InsnNode(opcode));
    }

    @Override
    public void visitIntInsn(int opcode, int operand) {
        this.instructions.add(new IntInsnNode(opcode, operand));
    }

    @Override
    public void visitVarInsn(int opcode, int varIndex) {
        this.instructions.add(new VarInsnNode(opcode, varIndex));
    }

    @Override
    public void visitTypeInsn(int opcode, String type) {
        this.instructions.add(new TypeInsnNode(opcode, type));
    }

    @Override
    public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
        this.instructions.add(new FieldInsnNode(opcode, owner, name, descriptor));
    }

    @Override
    public void visitMethodInsn(int opcodeAndSource, String owner, String name, String descriptor, boolean isInterface) {
        this.instructions.add(new MethodInsnNode(opcodeAndSource & ~Opcodes.SOURCE_MASK, owner, name, descriptor, isInterface));
    }

    @Override
    public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
        this.instructions.add(new InvokeDynamicInsnNode(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments));
    }

    @Override
    public void visitJumpInsn(int opcode, Label label) {
        this.instructions.add(new JumpInsnNode(opcode, getLabelNode(label)));
    }

    @Override
    public void visitLabel(Label label) {
        this.instructions.add(getLabelNode(label));
    }

    @Override
    public void visitLdcInsn(Object value) {
        this.instructions.add(new LdcInsnNode(value));
    }

    @Override
    public void visitIincInsn(int varIndex, int increment) {
        this.instructions.add(new IincInsnNode(varIndex, increment));
    }

    @Override
    public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
        this.instructions.add(new TableSwitchInsnNode(min, max, getLabelNode(dflt), getLabelNodes(labels)));
    }

    @Override
    public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
        this.instructions.add(new LookupSwitchInsnNode(getLabelNode(dflt), keys, getLabelNodes(labels)));
    }

    @Override
    public void visitMultiANewArrayInsn(String descriptor, int numDimensions) {
        this.instructions.add(new MultiANewArrayInsnNode(descriptor, numDimensions));
    }

    @Override
    public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        // Find the last real instruction, i.e. the instruction targeted by this annotation.
        AbstractInsnNode currentInsn = this.instructions.getLast();
        while (currentInsn.getOpcode() == -1) {
            currentInsn = currentInsn.getPrevious();
        }

        // Add the annotation to this instruction.
        TypeAnnotationNode typeAnnotation = new TypeAnnotationNode(typeRef, typePath, descriptor);
        if (visible) {
            currentInsn.visibleTypeAnnotations =
                    Util.add(currentInsn.visibleTypeAnnotations, typeAnnotation);
        } else {
            currentInsn.invisibleTypeAnnotations =
                    Util.add(currentInsn.invisibleTypeAnnotations, typeAnnotation);
        }

        return typeAnnotation;
    }

    @Override
    public void visitTryCatchBlock(final Label start, Label end, Label handler, String type) {
        TryCatchBlockNode tryCatchBlock =
                new TryCatchBlockNode(getLabelNode(start), getLabelNode(end), getLabelNode(handler), type);

        this.tryCatchBlocks = Util.add(tryCatchBlocks, tryCatchBlock);
    }

    @Override
    public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        TryCatchBlockNode tryCatchBlock = this.tryCatchBlocks.get((typeRef & 0x00FFFF00) >> 8);
        TypeAnnotationNode typeAnnotation = new TypeAnnotationNode(typeRef, typePath, descriptor);

        if (visible) {
            tryCatchBlock.visibleTypeAnnotations = 
                    Util.add(tryCatchBlock.visibleTypeAnnotations, typeAnnotation);
        } else {
            tryCatchBlock.invisibleTypeAnnotations = 
                    Util.add(tryCatchBlock.invisibleTypeAnnotations, typeAnnotation);
        }

        return typeAnnotation;
    }

    @Override
    public void visitLocalVariable(String name, String descriptor, String signature, Label start, Label end, int index) {
        this.localVariables = Util.add(this.localVariables,
                new LocalVariableNode(name, descriptor, signature, this.getLabelNode(start), this.getLabelNode(end), index)
        );
    }

    @Override
    public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, 
                                                          final int[] index, String descriptor, boolean visible) {
        LocalVariableAnnotationNode localVariableAnnotation = new LocalVariableAnnotationNode(
                typeRef, typePath, this.getLabelNodes(start), this.getLabelNodes(end), index, descriptor
        );

        if (visible) {
            this.visibleLocalVariableAnnotations =
                    Util.add(this.visibleLocalVariableAnnotations, localVariableAnnotation);
        } else {
            this.invisibleLocalVariableAnnotations =
                    Util.add(this.invisibleLocalVariableAnnotations, localVariableAnnotation);
        }
        
        return localVariableAnnotation;
    }

    @Override
    public void visitLineNumber(int line, Label start) {
        this.instructions.add(new LineNumberNode(line, getLabelNode(start)));
    }

    @Override
    public void visitMaxs(int maxStack, int maxLocals) {
        this.maxStack = maxStack;
        this.maxLocals = maxLocals;
    }

    /**
     * Returns the LabelNode corresponding to the given Label. Creates a new LabelNode if necessary.
     * The default implementation of this method uses the {@link Label#info} field to store
     * associations between labels and label nodes.
     *
     * @param label a Label.
     * @return the LabelNode corresponding to label.
     */
    protected LabelNode getLabelNode(Label label) {
        if (!(label.info instanceof LabelNode)) {
            label.info = new LabelNode();
        }
        
        return (LabelNode) label.info;
    }

    private LabelNode[] getLabelNodes(Label[] labels) {
        LabelNode[] labelNodes = new LabelNode[labels.length];
        for (int i = 0, n = labels.length; i < n; ++i) {
            labelNodes[i] = getLabelNode(labels[i]);
        }
        
        return labelNodes;
    }

    private Object[] getLabelNodes(Object[] objects) {
        Object[] labelNodes = new Object[objects.length];
        for (int i = 0, n = objects.length; i < n; ++i) {
            Object o = objects[i];
            if (o instanceof Label) {
                o = getLabelNode((Label) o);
            }

            labelNodes[i] = o;
        }
        
        return labelNodes;
    }

    // -----------------------------------------------------------------------------------------------
    // Accept method
    // -----------------------------------------------------------------------------------------------

    /**
     * Makes the given class visitor visit this method.
     *
     * @param classVisitor a class visitor.
     */
    public void accept(final ClassVisitor classVisitor) {
        String[] exceptionsArray = exceptions == null ? null : exceptions.toArray(new String[0]);
        MethodVisitor methodVisitor = classVisitor.visitMethod(access, name, desc, signature, exceptionsArray);

        if (methodVisitor != null) {
            this.accept(methodVisitor);
        }
    }

    /**
     * Makes the given method visitor visit this method.
     *
     * @param methodVisitor a method visitor.
     */
    public void accept(final MethodVisitor methodVisitor) {
        // Visit the parameters.
        if (this.parameters != null) {
            for (ParameterNode parameter : this.parameters) {
                parameter.accept(methodVisitor);
            }
        }

        // Visit the annotations.
        if (this.annotationDefault != null) {
            AnnotationVisitor annotationVisitor = methodVisitor.visitAnnotationDefault();
            AnnotationNode.accept(annotationVisitor, null, this.annotationDefault);
            if (annotationVisitor != null) {
                annotationVisitor.visitEnd();
            }
        }

        if (this.visibleAnnotations != null) {
            for (AnnotationNode annotation : this.visibleAnnotations) {
                annotation.accept(methodVisitor.visitAnnotation(annotation.desc, true));
            }
        }

        if (this.invisibleAnnotations != null) {
            for (AnnotationNode annotation : this.invisibleAnnotations) {
                annotation.accept(methodVisitor.visitAnnotation(annotation.desc, false));
            }
        }

        if (this.visibleTypeAnnotations != null) {
            for (TypeAnnotationNode typeAnnotation : this.visibleTypeAnnotations) {
                typeAnnotation.accept(
                        methodVisitor.visitTypeAnnotation(
                                typeAnnotation.typeRef, typeAnnotation.typePath, typeAnnotation.desc, true));
            }
        }

        if (this.invisibleTypeAnnotations != null) {
            for (TypeAnnotationNode typeAnnotation : this.invisibleTypeAnnotations) {
                typeAnnotation.accept(
                        methodVisitor.visitTypeAnnotation(
                                typeAnnotation.typeRef, typeAnnotation.typePath, typeAnnotation.desc, false));
            }
        }

        if (this.visibleAnnotableParameterCount > 0) {
            methodVisitor.visitAnnotableParameterCount(this.visibleAnnotableParameterCount, true);
        }

        if (this.visibleParameterAnnotations != null) {
            for (int i = 0, n = this.visibleParameterAnnotations.length; i < n; ++i) {
                List<AnnotationNode> parameterAnnotations = this.visibleParameterAnnotations[i];
                if (parameterAnnotations == null) {
                    continue;
                }

                for (AnnotationNode annotation : parameterAnnotations) {
                    annotation.accept(methodVisitor.visitParameterAnnotation(i, annotation.desc, true));
                }
            }
        }

        if (this.invisibleAnnotableParameterCount > 0) {
            methodVisitor.visitAnnotableParameterCount(this.invisibleAnnotableParameterCount, false);
        }

        if (this.invisibleParameterAnnotations != null) {
            for (int i = 0, n = this.invisibleParameterAnnotations.length; i < n; ++i) {
                List<AnnotationNode> parameterAnnotations = this.invisibleParameterAnnotations[i];
                if (parameterAnnotations == null) {
                    continue;
                }

                for (AnnotationNode annotation : parameterAnnotations) {
                    annotation.accept(methodVisitor.visitParameterAnnotation(i, annotation.desc, false));
                }
            }
        }

        // Visit the non-standard attributes.
        if (this.visited) {
            this.instructions.resetLabels();
        }

        if (this.attrs != null) {
            for (Attribute attr : this.attrs) {
                methodVisitor.visitAttribute(attr);
            }
        }

        // Visit the code.
        if (this.instructions.size() > 0) {
            methodVisitor.visitCode();
            // Visits the try catch blocks.
            if (this.tryCatchBlocks != null) {
                for (int i = 0, n = this.tryCatchBlocks.size(); i < n; ++i) {
                    this.tryCatchBlocks.get(i).updateIndex(i);
                    this.tryCatchBlocks.get(i).accept(methodVisitor);
                }
            }

            // Visit the instructions.
            this.instructions.accept(methodVisitor);

            // Visits the local variables.
            if (this.localVariables != null) {
                for (LocalVariableNode localVariable : this.localVariables) {
                    localVariable.accept(methodVisitor);
                }
            }

            // Visits the local variable annotations.
            if (this.visibleLocalVariableAnnotations != null) {
                for (LocalVariableAnnotationNode visibleLocalVariableAnnotation : this.visibleLocalVariableAnnotations) {
                    visibleLocalVariableAnnotation.accept(methodVisitor, true);
                }
            }

            if (this.invisibleLocalVariableAnnotations != null) {
                for (LocalVariableAnnotationNode invisibleLocalVariableAnnotation : this.invisibleLocalVariableAnnotations) {
                    invisibleLocalVariableAnnotation.accept(methodVisitor, false);
                }
            }

            methodVisitor.visitMaxs(maxStack, maxLocals);
            visited = true;
        }

        methodVisitor.visitEnd();
    }
}
