package test.echo;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import test.echo.simple.SimpleClassVisitor;

public class EchoClassVisitor extends ClassVisitor {

    private final SimpleClassVisitor original;

    public EchoClassVisitor(SimpleClassVisitor original) {
        super(Opcodes.ASM9);

        this.original = original;
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        return new EchoMethodVisitor(this.original.visitMethod(access, name, descriptor, signature, exceptions));
    }
}
