package test.echo.simple;

import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class SimpleMethodVisitor extends MethodVisitor {

    protected SimpleMethodVisitor() {
        super(Opcodes.ASM9);
    }

    @Override
    public void visitCode() {
        super.visitCode();
    }
}
