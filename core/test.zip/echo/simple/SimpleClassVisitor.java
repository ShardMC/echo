package test.echo.simple;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class SimpleClassVisitor extends ClassVisitor {

    private final SimpleMethodVisitor methodVisitor;

    public SimpleClassVisitor() {
        super(Opcodes.ASM9);

        this.methodVisitor = new SimpleMethodVisitor();
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        return methodVisitor;
    }
}
