package test.echo;

import org.objectweb.asm.*;

import java.util.ArrayList;
import java.util.List;

public class EchoMethodVisitor extends MethodVisitor {

    private final List<String> annotations = new ArrayList<>();
    private final MethodVisitor original;

    protected EchoMethodVisitor(MethodVisitor original) {
        super(Opcodes.ASM9);

        this.original = original;
    }

    @Override
    public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
        this.annotations.add(descriptor);
        return super.visitAnnotation(descriptor, visible);
    }

    @Override
    public void visitInsn(int opcode) {
        this.original.visitInsn(opcode);
        super.visitInsn(opcode);
    }

    @Override
    public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
        this.original.visitFieldInsn(opcode, owner, name, descriptor);
        super.visitFieldInsn(opcode, owner, name, descriptor);
    }

    @Override
    public void visitIincInsn(int varIndex, int increment) {
        this.original.visitIincInsn(varIndex, increment);
        super.visitIincInsn(varIndex, increment);
    }

    @Override
    public void visitIntInsn(int opcode, int operand) {
        this.original.visitIntInsn(opcode, operand);
        super.visitIntInsn(opcode, operand);
    }

    @Override
    public void visitJumpInsn(int opcode, Label label) {
        this.original.visitJumpInsn(opcode, label);
        super.visitJumpInsn(opcode, label);
    }

    @Override
    public void visitLdcInsn(Object value) {
        this.original.visitLdcInsn(value);
        super.visitLdcInsn(value);
    }

    @Override
    public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
        this.original.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
        super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
    }

    @Override
    public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
        this.original.visitInvokeDynamicInsn(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments);
        super.visitInvokeDynamicInsn(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments);
    }

    @Override
    public void visitTypeInsn(int opcode, String type) {
        this.original.visitTypeInsn(opcode, type);
        super.visitTypeInsn(opcode, type);
    }

    @Override
    public void visitVarInsn(int opcode, int varIndex) {
        this.original.visitVarInsn(opcode, varIndex);
        super.visitVarInsn(opcode, varIndex);
    }

    @Override
    public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
        this.original.visitLookupSwitchInsn(dflt, keys, labels);
        super.visitLookupSwitchInsn(dflt, keys, labels);
    }

    @Override
    public void visitMultiANewArrayInsn(String descriptor, int numDimensions) {
        this.original.visitMultiANewArrayInsn(descriptor, numDimensions);
        super.visitMultiANewArrayInsn(descriptor, numDimensions);
    }

    @Override
    public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
        super.visitTableSwitchInsn(min, max, dflt, labels);
    }

    @Override
    public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        this.original.visitInsnAnnotation(typeRef, typePath, descriptor, visible);
        return super.visitInsnAnnotation(typeRef, typePath, descriptor, visible);
    }

    @Override
    public AnnotationVisitor visitAnnotationDefault() {
        this.original.visitAnnotationDefault();
        return super.visitAnnotationDefault();
    }

    @Override
    public AnnotationVisitor visitLocalVariableAnnotation(int typeRef, TypePath typePath, Label[] start, Label[] end, int[] index, String descriptor, boolean visible) {
        this.original.visitLocalVariableAnnotation(typeRef, typePath, start, end, index, descriptor, visible);
        return super.visitLocalVariableAnnotation(typeRef, typePath, start, end, index, descriptor, visible);
    }

    @Override
    public AnnotationVisitor visitParameterAnnotation(int parameter, String descriptor, boolean visible) {
        this.original.visitParameterAnnotation(parameter, descriptor, visible);
        return super.visitParameterAnnotation(parameter, descriptor, visible);
    }

    @Override
    public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        this.original.visitTryCatchAnnotation(typeRef, typePath, descriptor, visible);
        return super.visitTryCatchAnnotation(typeRef, typePath, descriptor, visible);
    }

    @Override
    public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        this.original.visitTypeAnnotation(typeRef, typePath, descriptor, visible);
        return super.visitTypeAnnotation(typeRef, typePath, descriptor, visible);
    }

    @Override
    public void visitAnnotableParameterCount(int parameterCount, boolean visible) {
        this.original.visitAnnotableParameterCount(parameterCount, visible);
        super.visitAnnotableParameterCount(parameterCount, visible);
    }

    @Override
    public void visitAttribute(Attribute attribute) {
        this.original.visitAttribute(attribute);
        super.visitAttribute(attribute);
    }

    @Override
    public void visitFrame(int type, int numLocal, Object[] local, int numStack, Object[] stack) {
        this.original.visitFrame(type, numLocal, local, numStack, stack);
        super.visitFrame(type, numLocal, local, numStack, stack);
    }

    @Override
    public void visitLabel(Label label) {
        this.original.visitLabel(label);
        super.visitLabel(label);
    }

    @Override
    public void visitLineNumber(int line, Label start) {
        this.original.visitLineNumber(line, start);
        super.visitLineNumber(line, start);
    }

    @Override
    public void visitLocalVariable(String name, String descriptor, String signature, Label start, Label end, int index) {
        this.original.visitLocalVariable(name, descriptor, signature, start, end, index);
        super.visitLocalVariable(name, descriptor, signature, start, end, index);
    }

    @Override
    public void visitMaxs(int maxStack, int maxLocals) {
        this.original.visitMaxs(maxStack, maxLocals);
        super.visitMaxs(maxStack, maxLocals);
    }

    @Override
    public void visitParameter(String name, int access) {
        this.original.visitParameter(name, access);
        super.visitParameter(name, access);
    }

    @Override
    public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
        this.original.visitTryCatchBlock(start, end, handler, type);
        super.visitTryCatchBlock(start, end, handler, type);
    }

    @Override
    public void visitCode() {
        this.original.visitCode();
        super.visitCode();
    }

    @Override
    public void visitEnd() {
        this.original.visitEnd();
        super.visitEnd();
    }
}
