package test.asm;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Opcodes;
import test.asm.info.FieldInfo;
import test.visitor.Visitor;

import java.util.ArrayList;
import java.util.List;

public class ASMField extends FieldVisitor {

    private final FieldInfo info;
    private final List<String> annotations = new ArrayList<>();

    private final Visitor callback;

    public ASMField(FieldInfo info, Visitor callback) {
        super(Opcodes.ASM9);

        this.info = info;
        this.callback = callback;
    }

    @Override
    public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
        this.annotations.add(desc);
        return super.visitAnnotation(desc, visible);
    }

    @Override
    public void visitEnd() {
        this.callback.onField(this);
    }

    public FieldInfo getInfo() {
        return this.info;
    }

    public List<String> getAnnotations() {
        return this.annotations;
    }

    @Override
    public String toString() {
        return String.format("SimpleField{info=%s, annotations=%s}",
                this.getInfo(), this.getAnnotations()
        );
    }
}
