package test.asm;

import org.objectweb.asm.*;
import test.asm.info.ClassInfo;
import test.asm.info.FieldInfo;
import test.asm.info.MethodInfo;
import test.visitor.Visitor;

import java.util.ArrayList;
import java.util.List;

public class ASMClass extends ClassVisitor {

    private ClassInfo info;
    private final List<String> annotations = new ArrayList<>();

    private final Visitor visitor;

    public ASMClass(Visitor visitor) {
        super(Opcodes.ASM9);

        this.visitor = visitor;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        this.info = this.visitor.onClassInfo(new ClassInfo(access, name, superName, interfaces));
        super.visit(version, this.info.getAccess(), this.info.getName(), signature, this.info.getSuperName(), this.info.getInterfaces());
    }

    @Override
    public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
        this.annotations.add(desc);
        return super.visitAnnotation(desc, visible);
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        return new ASMMethod(
                this.visitor.onMethodInfo(new MethodInfo(access, name, descriptor, signature, exceptions)), this.visitor
        );
    }

    @Override
    public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
        return new ASMField(
                this.visitor.onFieldInfo(new FieldInfo(access, name, descriptor, signature, value)), this.visitor
        );
    }

    @Override
    public void visitEnd() {
        this.visitor.onEnd(this);
    }

    public ClassInfo getInfo() {
        return this.info;
    }

    public List<String> getAnnotations() {
        return this.annotations;
    }

    @Override
    public String toString() {
        return String.format("SimpleClass{info=%s, annotations=%s}",
                this.getInfo(), this.getAnnotations()
        );
    }
}
