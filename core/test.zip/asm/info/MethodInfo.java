package test.asm.info;

import java.util.Arrays;

public class MethodInfo {
    private int access;
    private String name;
    private String desc;
    private String signature;
    private String[] exceptions;

    public MethodInfo(int access, String name, String desc, String signature, String[] exceptions) {
        this.access = access;
        this.name = name;
        this.desc = desc;
        this.signature = signature;
        this.exceptions = exceptions;
    }

    public int getAccess() {
        return this.access;
    }

    public String getName() {
        return this.name;
    }

    public String getDesc() {
        return this.desc;
    }

    public String getSignature() {
        return signature;
    }

    public String[] getExceptions() {
        return exceptions;
    }

    public void setAccess(int access) {
        this.access = access;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public void setExceptions(String[] exceptions) {
        this.exceptions = exceptions;
    }

    @Override
    public String toString() {
        return String.format("MethodInfo{access=%s, name='%s', desc='%s', signature='%s' exceptions=%s}",
                this.getAccess(), this.getName(), this.getDesc(), this.getSignature(),Arrays.toString(this.getExceptions())
        );
    }
}
