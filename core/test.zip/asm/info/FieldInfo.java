package test.asm.info;

public class FieldInfo {
    private int access;
    private String name;
    private String desc;
    private String signature;
    private Object value;

    public FieldInfo(int access, String name, String desc, String signature, Object value) {
        this.access = access;
        this.name = name;
        this.desc = desc;
        this.signature = signature;
        this.value = value;
    }

    public int getAccess() {
        return access;
    }

    public void setAccess(int access) {
        this.access = access;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.format("FieldInfo{access=%s, name='%s', desc='%s', signature='%s', value=%s}",
                this.getAccess(), this.getName(), this.getDesc(), this.getSignature(), this.getValue()
        );
    }
}
