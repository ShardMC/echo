package test.asm.info;

import java.util.Arrays;

public class ClassInfo {
    private int access;
    private String name;
    private String superName;
    private String[] interfaces;

    public ClassInfo(int access, String name, String superName, String[] interfaces) {
        this.access = access;
        this.name = name;
        this.superName = superName;
        this.interfaces = interfaces;
    }

    public int getAccess() {
        return access;
    }

    public void setAccess(int access) {
        this.access = access;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSuperName() {
        return superName;
    }

    public void setSuperName(String superName) {
        this.superName = superName;
    }

    public String[] getInterfaces() {
        return interfaces;
    }

    public void setInterfaces(String[] interfaces) {
        this.interfaces = interfaces;
    }

    @Override
    public String toString() {
        return String.format("ClassInfo{access=%s, name='%s', superName='%s', interfaces=%s}",
                this.getAccess(), this.getName(), this.getSuperName(), Arrays.toString(this.getInterfaces())
        );
    }
}
