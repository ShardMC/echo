package test.asm;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import test.asm.info.MethodInfo;
import test.visitor.Visitor;

import java.util.ArrayList;
import java.util.List;

public class ASMMethod extends MethodVisitor {

    private final MethodInfo info;
    private final List<String> annotations = new ArrayList<>();

    private final Visitor callback;

    public ASMMethod(MethodInfo info, Visitor callback) {
        super(Opcodes.ASM9);

        this.info = info;
        this.callback = callback;
    }

    @Override
    public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
        this.annotations.add(desc);
        return super.visitAnnotation(desc, visible);
    }

    @Override
    public void visitEnd() {
        this.callback.onMethod(this);
    }

    public MethodInfo getInfo() {
        return this.info;
    }

    public List<String> getAnnotations() {
        return this.annotations;
    }

    @Override
    public String toString() {
        return String.format("SimpleMethod{info=%s, annotations=%s}",
                this.getInfo(), this.getAnnotations()
        );
    }
}