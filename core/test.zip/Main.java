package test;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.util.TraceClassVisitor;
import test.echo.EchoClassVisitor;
import test.echo.simple.SimpleClassVisitor;

import java.io.IOException;
import java.io.PrintWriter;

public class Main {
    public static void main(String[] args) throws IOException {
        /*ASMClass original = new ASMClass(new SimpleVisitor());
        new ClassReader("test.cases.DummyEdit").accept(original, ClassReader.EXPAND_FRAMES);*/
        SimpleClassVisitor original = new SimpleClassVisitor();
        EchoClassVisitor echo = new EchoClassVisitor(original);

        ClassReader reader = new ClassReader("test.cases.DummyOriginal");
        reader.accept(original, ClassReader.EXPAND_FRAMES);

        new ClassReader("test.cases.DummyEdit").accept(echo, 0);

        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES);
        reader.accept(writer, 0);

        new ClassReader(writer.toByteArray()).accept(new TraceClassVisitor(new PrintWriter(System.out)), 0);
    }
}
