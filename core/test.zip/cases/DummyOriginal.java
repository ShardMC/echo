package test.cases;

public class DummyOriginal {

}
