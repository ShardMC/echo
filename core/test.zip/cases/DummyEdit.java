package test.cases;

public class DummyEdit {
    public void test() {

    }
}
