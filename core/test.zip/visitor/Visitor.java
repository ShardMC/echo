package test.visitor;

import test.asm.*;
import test.asm.info.ClassInfo;
import test.asm.info.FieldInfo;
import test.asm.info.MethodInfo;

public interface Visitor {
    default ClassInfo onClassInfo(ClassInfo clazz) { return clazz; }

    default MethodInfo onMethodInfo(MethodInfo method) { return method; }
    default void onMethod(ASMMethod method) { }

    default FieldInfo onFieldInfo(FieldInfo field) { return field; }
    default void onField(ASMField field) { }

    default void onEnd(ASMClass clazz) { }
}
