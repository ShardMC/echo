package test.visitor.impl;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;
import test.asm.ASMClass;
import test.asm.ASMMethod;
import test.asm.info.ClassInfo;
import test.asm.info.FieldInfo;
import test.visitor.Visitor;

public class SimpleVisitor implements Visitor {

    private OriginalClass originalClass;

    @Override
    public ClassInfo onClassInfo(ClassInfo clazz) {
        try {
            this.originalClass = new OriginalClass();
            new ClassReader("test.cases.DummyOriginal").accept(this.originalClass, ClassReader.EXPAND_FRAMES);
        } catch (Exception ignored) { }

        return clazz;
    }

    @Override
    public void onMethod(ASMMethod method) {
        System.out.println("  Method: " + method);
    }

    @Override
    public FieldInfo onFieldInfo(FieldInfo field) {
        this.originalClass.visitField(field.getAccess(), field.getName(), field.getDesc(), field.getSignature(), field.getValue());
        return field;
    }

    @Override
    public void onEnd(ASMClass clazz) {
        System.out.println("Class: " + clazz);
    }

    static class OriginalClass extends ClassVisitor {

        protected OriginalClass() {
            super(Opcodes.ASM9);
        }
    }
}
